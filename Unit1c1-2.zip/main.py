import math
num=5
factorial=math.factorial(num)
print("The factorial of",num,"is",factorial)